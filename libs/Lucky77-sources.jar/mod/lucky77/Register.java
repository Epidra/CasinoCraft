package mod.lucky77;

import mod.lucky77.custom.content.RegisterMod;
import mod.lucky77.custom.content.RegisterSeed;

public class Register {
	
	public static RegisterMod MODS = new RegisterMod();
	public static RegisterSeed SEEDS = new RegisterSeed();
	
}
