package mod.lucky77.client.screen.base;

import mod.lucky77.client.menu.MenuBase;
import mod.lucky77.custom.button.ButtonSet;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class ScreenBase<T extends MenuBase> extends AbstractContainerScreen<T> {
	
	protected final ButtonSet buttonSet = new ButtonSet();
	
	//   -------- -------- -------- --------     CONSTRUCTOR     -------- -------- -------- --------   //
	
	public ScreenBase(T container, Inventory playerInventory, Component name, int imageWidth, int imageHeight){
		super(container, playerInventory, name);
		this.imageWidth = imageWidth;
		this.imageHeight = imageHeight;
		createButtons();
	}
	
	//   -------- -------- -------- --------     INITIALIZATION     -------- -------- -------- --------   //
	
	@Override
	public void init(){
		super.init();
		this.titleLabelX = (this.imageWidth - this.font.width(this.title)) / 2;
	}
	
	protected abstract void createButtons();
	
	//   -------- -------- -------- --------     TICK     -------- -------- -------- --------   //
	
	@Override
	public void containerTick(){
	
	}
	
	//   -------- -------- -------- --------     INPUT     -------- -------- -------- --------   //
	
	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers){
		return super.keyPressed(keyCode, scanCode, modifiers);
	}
	
	//   -------- -------- -------- --------     RENDER     -------- -------- -------- --------   //
	
	@Override
	public void render(GuiGraphics guiGraphics, int mousePosX, int mousePosY, float partialTick){
		this.renderBackground(guiGraphics, mousePosX, mousePosY, partialTick);
		buttonSet.update(leftPos, topPos, mousePosX, mousePosY);
		renderBackGround(guiGraphics, mousePosX, mousePosY, partialTick);
		renderForeGround(guiGraphics, mousePosX, mousePosY, partialTick);
		this.renderTooltip(guiGraphics, mousePosX, mousePosY);
	}
	
	protected abstract void renderBackGround(GuiGraphics guiGraphics, int mousePosX, int mousePosY, float partialTick);
	protected abstract void renderForeGround(GuiGraphics guiGraphics, int mousePosX, int mousePosY, float partialTick);
	
	//   -------- -------- -------- --------     SUPPORT     -------- -------- -------- --------   //
	
	@Override
	public boolean isPauseScreen(){
		return false;
	}
	
	protected boolean mouseRect(int x, int y, int width, int height, double mouseX, double mouseY){
		if(leftPos + x < mouseX && mouseX < leftPos + x + width){
			return topPos + y < mouseY && mouseY < topPos + y + height;
		}
		return false;
	}
	
}
