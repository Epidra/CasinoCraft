package mod.lucky77.custom.content;

public class Dummy {
	
	// ...
	
	
	
	
	
	//   -------- -------- -------- --------     CONSTRUCTOR     -------- -------- -------- --------   //
	
	/** Empty Constructor of the Logic Dummy **/
	public Dummy(){
	
	}
	
	
	
	
	
	//   -------- -------- -------- --------     SUPPORT     -------- -------- -------- --------   //
	
	// ...
	
	
	
}
